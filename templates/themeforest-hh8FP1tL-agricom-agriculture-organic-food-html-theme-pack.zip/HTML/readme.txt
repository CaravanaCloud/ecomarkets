Clone .htaccess file in "dist" folder

Gulp command:
gulp clean
gulp
gulp watch